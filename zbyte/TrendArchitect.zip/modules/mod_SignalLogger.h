#pragma once
// mod_SignalLogger.h — [v9.3 V2/V4, ENHANCEMENT — no Pine equivalent]
// Logs every CONFIRMED (closed-bar) PRISM signal to CSV once resolved, so the
// gate thresholds can be validated against actual outcomes on the trader's
// own charts (execution/analyze_signals.py consumes these files).
//
// Design invariants:
//  - CLOSED bars only: signal state is read from the marker subgraphs at
//    bars < the live bar, where the last tick's write is final. Repaint-proof
//    by construction; identical rows whether display is Live or Bar Close.
//  - LIVE and REPLAY are separate streams: routed by sc.ReplayStatus into
//    "-TA-signals-" (real-time) and "-TA-replay-" (Chart Replay) files so their
//    current/historical timestamps never interleave. LIVE's watermark on its
//    first gated call either RESUMES from today's file (last logged fire-time)
//    or, if no file exists yet, BACKFILLS the whole current trading session —
//    so attaching/rebuilding mid-session still logs the session's signals,
//    exactly once. REPLAY inits at the replay-start bar and resets each run.
//  - ONE FILE PER TRADING DAY: filename {YYYYMMDD}-{prefix}-{SYM}-ch{N}.csv,
//    keyed by the SIGNAL's trading day (sc.GetTradingDayDate of fire-time), so
//    a signal that resolves after the session boundary still files under its
//    own session — and each replayed day lands in its own file.
//  - Resolution mirrors the Auto-Optimizer's ATR tiers (0.75/1.5/2.5 from the
//    AO inputs) over a FIXED K-bar window (AO's next-signal censoring would
//    make MFE/MAE non-comparable across rows), tracking BOTH MFE and MAE.
//  - One file append per RESOLVED signal (minutes apart at worst) via the
//    ACSIL file API: sc.OpenFile(FILE_MODE_OPEN_TO_APPEND)/WriteFile/CloseFile.
//    First error latches log_io_disabled — no error-loop spam.

#include <cstdio>
#include <cstring>
#include <cstdlib>   // atof — resume parsing
#include <cctype>
#include <string>
#include <algorithm> // std::nth_element / min / max
#include "../include/TA_Subgraphs.h"
#include "../include/TA_Inputs.h"
#include "../include/TA_State.h"

static const int SIGLOG_SCHEMA_VER = 2;   // [v9.4] +diagnostics/geometry/conf cols

// The one true header for the current schema (shared by the writer and the
// "already present?" check so they can never drift).
static const char* SIGLOG_HDR =
    "schema_ver,fire_time_raw,fire_time,symbol,bar_period,direction,class,"
    "sig_path,elev_mask,entry,atr,mfe_atr,mae_atr,tier,bars_held,flicker,"
    "er,er_rank,fk_norm,bq_ratio,cvd_rank,cvd_agree,delta_real,chop,"
    "trg_bull_votes,trg_bear_votes,suppressed,hurst,kama_align,sc_cco,"
    "ao_eff_len,rrg_votes,est_sec_per_bar,"
    "se_norm,fit_f,fit_r2,margin_atr,poly_slope,poly_curv,consensus,conf_pct\n";

// Trading-day (YYYYMMDD) of a fire-time, per the chart's configured Session
// Times — this keys each session to its own file and rolls the file over at
// the session boundary (e.g. 17:00 ET for CME index/metal futures).
inline int siglog_trading_day(SCStudyInterfaceRef sc, double fire_time)
{
    // Direct-init so this holds whether GetTradingDayDate returns an SCDateTime
    // or an int date serial (both construct the same SCDateTime).
    SCDateTime td(sc.GetTradingDayDate(SCDateTime(fire_time)));
    return td.GetYear() * 10000 + td.GetMonth() * 100 + td.GetDay();
}

// All TA logs live in a TA-logs subfolder of the Data Files Folder.
inline SCString siglog_folder(SCStudyInterfaceRef sc)
{
    SCString dir;
    dir.Format("%s\\TA-logs", sc.DataFilesFolder().GetChars());
    return dir;
}

// Create the TA-logs subfolder once per session. sc.OpenFile does NOT create
// missing directories, so this must run before any read/write. Idempotent — an
// existing folder returns ERROR_ALREADY_EXISTS, which we ignore.
inline void siglog_ensure_dir(SCStudyInterfaceRef sc, TAState& tas)
{
    if (tas.log_dir_ensured) return;
    CreateDirectoryA(siglog_folder(sc).GetChars(), NULL);
    tas.log_dir_ensured = true;
}

// Per-session CSV path: TA-logs\{YYYYMMDD}-{prefix}-{SYM}-ch{N}.csv, where
// prefix is "TA-signals" (real-time) or "TA-replay" (Chart Replay). Symbol
// sanitized for a filename; chart number separates distinct charts.
inline SCString siglog_path(SCStudyInterfaceRef sc, const char* prefix, int trading_day)
{
    SCString path, sym = sc.Symbol;
    char clean[64] = {};
    int n = 0;
    for (int i = 0; sym[i] != '\0' && n < 60; i++) {
        char c = sym[i];
        clean[n++] = (isalnum((unsigned char)c) || c == '-' || c == '_') ? c : '_';
    }
    path.Format("%s\\%08d-%s-%s-ch%d.csv", siglog_folder(sc).GetChars(),
                trading_day, prefix, clean, sc.ChartNumber);
    return path;
}

// Append one line to the per-chart CSV; returns false on I/O failure.
inline bool siglog_append(SCStudyInterfaceRef sc, const char* prefix, int trading_day, const char* line)
{
    int handle = 0;
    if (!sc.OpenFile(siglog_path(sc, prefix, trading_day), n_ACSIL::FILE_MODE_OPEN_TO_APPEND, handle))
        return false;
    unsigned int written = 0;
    bool ok = sc.WriteFile(handle, line, (int)strlen(line), &written) != 0;
    sc.CloseFile(handle);
    return ok;
}

// True if the CURRENT schema header already appears in the file. Read once per
// session (first gated call), so scanning the whole file is cheap. Returns
// false for a missing file (→ write header) and for an OLDER-schema file that
// lacks the current header (→ append the new header before the new-schema rows,
// which the analyzer keys off per embedded header).
inline bool siglog_has_current_header(SCStudyInterfaceRef sc, const char* prefix, int trading_day)
{
    int handle = 0;
    if (!sc.OpenFile(siglog_path(sc, prefix, trading_day), n_ACSIL::FILE_MODE_OPEN_EXISTING_FOR_SEQUENTIAL_READING, handle))
        return false;
    std::string buf;
    char chunk[8192];
    unsigned int got = 0;
    for (int guard = 0; guard < 2048; guard++) {   // cap ~16MB (far above real)
        if (!sc.ReadFile(handle, chunk, sizeof(chunk), &got) || got == 0) break;
        buf.append(chunk, got);
        if (got < sizeof(chunk)) break;
    }
    sc.CloseFile(handle);
    // Compare against the header without its trailing newline.
    std::string hdr(SIGLOG_HDR);
    if (!hdr.empty() && hdr[hdr.size() - 1] == '\n') hdr.erase(hdr.size() - 1);
    return buf.find(hdr) != std::string::npos;
}

inline void siglog_write_header_if_new(SCStudyInterfaceRef sc, TAState& tas,
                                       const char* prefix, int trading_day)
{
    // Write the header ONCE per file for the current schema — only if it isn't
    // already present. Called lazily the first time a given day's file is
    // written (per stream), so each per-session file gets exactly one header.
    if (siglog_has_current_header(sc, prefix, trading_day)) return;
    if (!siglog_append(sc, prefix, trading_day, SIGLOG_HDR))
        tas.log_io_disabled = true;
}

// Truncate a file to empty and write just the header (REPLAY overwrite): a
// fresh replay RUN discards any prior run's rows for the same day.
inline void siglog_rewrite_header(SCStudyInterfaceRef sc, TAState& tas,
                                  const char* prefix, int trading_day)
{
    int handle = 0;
    if (!sc.OpenFile(siglog_path(sc, prefix, trading_day),
                     n_ACSIL::FILE_MODE_OPEN_TO_REWRITE_FROM_START, handle)) {
        tas.log_io_disabled = true;
        return;
    }
    unsigned int written = 0;
    sc.WriteFile(handle, SIGLOG_HDR, (int)strlen(SIGLOG_HDR), &written);
    sc.CloseFile(handle);
}

// Largest fire_time_raw (column 2) already recorded in a file, or -1 if the
// file is absent/empty. Used to RESUME a live session after a Sierra restart:
// the watermark jumps to the last logged signal so gap signals fired while
// closed get appended exactly once (rows already on disk are never re-logged).
inline double siglog_last_fire_time(SCStudyInterfaceRef sc, const char* prefix, int trading_day)
{
    int handle = 0;
    if (!sc.OpenFile(siglog_path(sc, prefix, trading_day),
                     n_ACSIL::FILE_MODE_OPEN_EXISTING_FOR_SEQUENTIAL_READING, handle))
        return -1.0;
    std::string buf;
    char chunk[8192];
    unsigned int got = 0;
    for (int guard = 0; guard < 2048; guard++) {
        if (!sc.ReadFile(handle, chunk, sizeof(chunk), &got) || got == 0) break;
        buf.append(chunk, got);
        if (got < sizeof(chunk)) break;
    }
    sc.CloseFile(handle);
    double maxfire = -1.0;
    for (size_t pos = 0; pos < buf.size(); ) {
        size_t eol = buf.find('\n', pos);
        if (eol == std::string::npos) eol = buf.size();
        // skip the schema header line(s); parse fire_time_raw from data rows
        if (buf.compare(pos, 10, "schema_ver") != 0) {
            size_t c1 = buf.find(',', pos);
            if (c1 != std::string::npos && c1 < eol) {
                size_t c2 = buf.find(',', c1 + 1);
                if (c2 != std::string::npos && c2 <= eol) {
                    double v = atof(buf.substr(c1 + 1, c2 - c1 - 1).c_str());
                    if (v > maxfire) maxfire = v;
                }
            }
        }
        pos = eol + 1;
    }
    return maxfire;
}

// Chart bar-period info → tas.log_period_str ("500T"/"60s"/…) and
// tas.est_sec_per_bar (authoritative for time charts; median of the last 300
// bar durations for tick/volume/range charts — sc.SecondsPerBar is deprecated
// and 0 on non-time bars, which left PRISM Adaptive dead on tick charts).
// Recomputed with force=true on every full recalculation (idx==0). The logger
// ALSO calls it with force=false before writing rows: a DLL hot-swap can hand
// the study fresh state with NO full recalc, and rows resolved before the next
// recalc then logged a blank bar_period / zero est_sec_per_bar (live 2026-07-09).
inline void ta_detect_period_info(SCStudyInterfaceRef sc, TAState& tas, bool force)
{
    if (!force && tas.log_period_str.GetChars()[0] != '\0') return;
    n_ACSIL::s_BarPeriod bp;
    sc.GetBarPeriodParameters(bp);
    bool is_time_bars = (bp.ChartDataType == INTRADAY_DATA
                      && bp.IntradayChartBarPeriodType == IBPT_DAYS_MINS_SECS);
    if (is_time_bars) {
        tas.est_sec_per_bar = (double)bp.IntradayChartBarPeriodParameter1;
        tas.log_period_str.Format("%ds", bp.IntradayChartBarPeriodParameter1);
    } else {
        tas.est_sec_per_bar = 0.0;
        if ((bool)sc.Input[IN_ADAPT_TICK_EST].GetYesNo() && sc.ArraySize > 20) {
            int nd = std::min(sc.ArraySize - 1, 300);
            float* dur = ta_scratch(tas.scratch_a, nd);
            for (int k = 0; k < nd; k++) {
                int j = sc.ArraySize - 1 - k;
                dur[k] = (float)((sc.BaseDateTimeIn[j].GetAsDouble()
                                - sc.BaseDateTimeIn[j - 1].GetAsDouble()) * 86400.0);
            }
            std::nth_element(dur, dur + nd / 2, dur + nd);
            tas.est_sec_per_bar = std::max(1.0, (double)dur[nd / 2]);
        }
        const char* bt = (bp.IntradayChartBarPeriodType == IBPT_NUM_TRADES_PER_BAR) ? "T"
                       : (bp.IntradayChartBarPeriodType == IBPT_VOLUME_PER_BAR)     ? "V" : "R";
        tas.log_period_str.Format("%d%s", bp.IntradayChartBarPeriodParameter1, bt);
    }
}

// Called once per NEW live bar (bar_advanced), after all modules computed.
// Enqueues confirmed signals from the just-closed bar(s) past the watermark,
// updates pending MFE/MAE with the just-closed bar, resolves aged entries.
inline void compute_SignalLogger(
    SCStudyInterfaceRef sc,
    TAState& tas,
    bool   enabled,
    bool   include_mq,
    int    horizon_bars,      // 0 = follow IN_AO_MAX_BARS
    float  tier1, float tier2, float tier3)   // AO ATR tiers
{
    if (!enabled || tas.log_io_disabled) return;
    if (sc.IsFullRecalculation || sc.DownloadingHistoricalData) return;

    int live = sc.ArraySize - 1;
    if (live < 1) return;

    // Self-heal the bar-period info before any row can be written — a DLL
    // hot-swap reaches here with fresh state and no idx==0 pass having run.
    ta_detect_period_info(sc, tas, false);

    // ── Route by data source ────────────────────────────────────────────────
    // Real-time and Chart Replay each own a stream + file family so their rows
    // (current vs historical timestamps) never interleave. Replay is NOT
    // dropped — it lands in "-TA-replay-" files, keyed by the replayed trading
    // day, so each replay day is its own file for the analyzer.
    bool is_replay = (sc.ReplayStatus != 0);          // running OR paused/stepped
    if (is_replay && !tas.was_replay)                 // fresh replay run → clean slate
        tas.log_replay = SigLogStream();
    tas.was_replay = is_replay;
    const char* prefix = is_replay ? "TA-replay" : "TA-signals";
    SigLogStream& s = is_replay ? tas.log_replay : tas.log_live;
    siglog_ensure_dir(sc, tas);   // create TA-logs before any read/write

    // First gated call for this stream: set the watermark that gates logging.
    // LIVE:
    //   • today's file already exists (Sierra restarted / study re-added mid-
    //     session) → RESUME from the last logged signal (+1e-8 day beats the
    //     %.8f round-trip) so only newer signals append, never duplicated.
    //   • no file yet → BACKFILL the whole current trading session: seed the
    //     watermark to JUST BEFORE the first bar of today's session so every
    //     signal already on the chart (they fired before this attach) gets
    //     logged. Without this, attaching mid-session — or every rebuild/re-add —
    //     would start the log at "now" and silently skip the session's signals.
    // REPLAY: overwrites its file, so always init at the replay-start bar.
    if (s.watermark < 0.0) {
        double last_bar = sc.BaseDateTimeIn[live - 1].GetAsDouble();
        if (is_replay) {
            s.watermark = last_bar;
        } else {
            int today = siglog_trading_day(sc, last_bar);
            double resume = siglog_last_fire_time(sc, prefix, today);
            if (resume > 0.0) {
                s.watermark = resume + 1.0e-8;              // resume: append only new
            } else {
                int b0 = live;                              // first bar of today's session
                while (b0 > 0 &&
                       siglog_trading_day(sc, sc.BaseDateTimeIn[b0 - 1].GetAsDouble()) == today)
                    b0--;
                s.watermark = (b0 > 0)
                    ? sc.BaseDateTimeIn[b0 - 1].GetAsDouble()        // prior session's last bar
                    : sc.BaseDateTimeIn[0].GetAsDouble() - 1.0e-8;   // whole chart is today
            }
        }
        return;
    }

    int K = (horizon_bars > 0) ? horizon_bars : 7;

    // ── 1. Update + resolve pending with each newly closed bar ──────────────
    // Walk forward over the newly closed bars (usually exactly one)
    int first_new = live;   // first bar index with time > watermark
    while (first_new >= 1
        && sc.BaseDateTimeIn[first_new - 1].GetAsDouble() > s.watermark)
        first_new--;

    for (int b = first_new; b < live; b++) {
        // 1a. progress existing pendings with bar b's range
        for (size_t i = 0; i < s.pending.size(); i++) {
            SigLogPending& p = s.pending[i];
            if (p.bars_held < 0) continue;               // resolved, awaiting erase
            if (sc.BaseDateTimeIn[b].GetAsDouble() <= p.fire_time) continue;
            double fav = (p.dir == 1) ? ((double)sc.High[b] - p.entry)
                                      : (p.entry - (double)sc.Low[b]);
            double adv = (p.dir == 1) ? (p.entry - (double)sc.Low[b])
                                      : ((double)sc.High[b] - p.entry);
            if (p.atr > 0.0) {
                p.mfe = std::max(p.mfe, fav / p.atr);
                p.mae = std::max(p.mae, adv / p.atr);
            }
            if      (p.mfe >= (double)tier3) p.tier = 3;
            else if (p.mfe >= (double)tier2) p.tier = std::max(p.tier, 2);
            else if (p.mfe >= (double)tier1) p.tier = std::max(p.tier, 1);
            p.bars_held++;
            // [v9.4 FIX-8b] Resolve on the FIXED K-bar window only (tier is
            // already latched when reached), so mfe_atr AND mae_atr are
            // comparable across every row — the earlier `tier>=3 ||` early-out
            // censored the MAE of strong winners, biasing the analyzer's
            // threshold sweeps toward early-resolved winners.
            if (p.bars_held >= K) {
                // resolve → write row. First touch of this day's file THIS run:
                // live → ensure header (append if missing, never duplicated);
                // replay → truncate+header (a re-run overwrites the prior run).
                // written_days makes a boundary-straddling late resolve APPEND,
                // never re-truncate an already-open replay file.
                bool first_touch = true;
                for (size_t j = 0; j < s.written_days.size(); j++)
                    if (s.written_days[j] == p.file_day) { first_touch = false; break; }
                if (first_touch) {
                    s.written_days.push_back(p.file_day);
                    if (is_replay) siglog_rewrite_header(sc, tas, prefix, p.file_day);
                    else           siglog_write_header_if_new(sc, tas, prefix, p.file_day);
                    if (tas.log_io_disabled) return;
                }
                char line[1024];
                SCString ts = sc.DateTimeToString(SCDateTime(p.fire_time),
                                                  FLAG_DT_COMPLETE_DATETIME);
                snprintf(line, sizeof(line),
                    "%d,%.8f,%s,%s,%s,%d,%s,%d,%d,%.6f,%.6f,%.4f,%.4f,%d,%d,%d,"
                    "%.4f,%.1f,%.4f,%.3f,%.1f,%d,%d,%d,%d,%d,%d,%.3f,%.1f,%.1f,%d,%d,%.1f,"
                    "%.4f,%.3f,%.4f,%.4f,%.5f,%.6f,%d,%.1f\n",
                    SIGLOG_SCHEMA_VER, p.fire_time, ts.GetChars(),
                    sc.Symbol.GetChars(), tas.log_period_str.GetChars(),
                    p.dir, p.marginal ? "MQ" : "FULL",
                    p.f_sig_path, p.f_elev_mask,
                    p.entry, p.atr, p.mfe, p.mae, p.tier, p.bars_held, p.flicker,
                    p.f_er, p.f_er_rank, p.f_fk_norm, p.f_bq_ratio,
                    p.f_cvd_rank, p.f_cvd_agree, p.f_delta_real, p.f_chop,
                    p.f_trg_bull_votes, p.f_trg_bear_votes, p.f_suppressed,
                    p.f_hurst, p.f_kama_align * 100.0, p.f_sc_cco,
                    // est_sec_per_bar from the SAME self-healed member as
                    // bar_period — never a stale-at-entry copy (v9.4.3)
                    p.f_ao_eff_len, p.f_rrg_votes, tas.est_sec_per_bar,
                    p.f_se_norm, p.f_fit_f, p.f_fit_r2, p.f_margin_atr,
                    p.f_poly_slope, p.f_poly_curv, p.f_consensus, p.f_conf_pct);
                if (!siglog_append(sc, prefix, p.file_day, line)) { tas.log_io_disabled = true; return; }
                p.bars_held = -1;   // mark for erase
            }
        }
        // erase resolved
        for (int i = (int)s.pending.size() - 1; i >= 0; i--)
            if (s.pending[i].bars_held < 0)
                s.pending.erase(s.pending.begin() + i);

        // 1b. enqueue new confirmed signals from bar b (marker subgraphs hold
        // the bar's FINAL state once it is no longer the live bar)
        bool fb = sc.Subgraph[SG_PRISM_BULL][b]    != 0.0f;
        bool fr = sc.Subgraph[SG_PRISM_BEAR][b]    != 0.0f;
        bool mb = sc.Subgraph[SG_PRISM_MQ_BULL][b] != 0.0f;
        bool mr = sc.Subgraph[SG_PRISM_MQ_BEAR][b] != 0.0f;
        if ((fb || fr || (include_mq && (mb || mr))) && s.pending.size() < 64) {
            SigLogPending p;
            p.fire_time = sc.BaseDateTimeIn[b].GetAsDouble();
            p.file_day  = siglog_trading_day(sc, p.fire_time);   // file keyed by fire day
            p.dir       = (fb || mb) ? 1 : -1;
            p.marginal  = !(fb || fr);
            p.entry     = (double)sc.Close[b];
            p.atr       = (double)sc.Subgraph[SG_RRG_STORE][b];   // ATR14 history
            // flicker snapshot for this bar (V4; -1 = not observed live)
            p.flicker   = (tas.fin_flicker_time == p.fire_time)
                        ? tas.fin_flicker_count : -1;
            // fire-time feature vector from the hidden stashes
            p.f_er         = (double)sc.Subgraph[SG_RAW_ER][b];
            p.f_er_rank    = (double)sc.Subgraph[SG_RAW_CCO].Arrays[0][b];
            p.f_fk_norm    = (double)sc.Subgraph[SG_RAW_ER].Arrays[0][b];
            p.f_bq_ratio   = (double)sc.Subgraph[SG_RAW_ER].Arrays[1][b];
            p.f_chop       = (int)sc.Subgraph[SG_RAW_ER].Arrays[2][b];
            p.f_sig_path   = (int)sc.Subgraph[SG_RAW_ER].Arrays[3][b];
            p.f_elev_mask  = (int)sc.Subgraph[SG_RAW_ER].Arrays[4][b];
            p.f_cvd_rank   = (double)sc.Subgraph[SG_CVD_STORE].Arrays[0][b];
            double dnet    = (double)sc.Subgraph[SG_CVD_STORE].Arrays[1][b];
            p.f_cvd_agree  = ((p.dir == 1 && dnet > 0.0) || (p.dir == -1 && dnet < 0.0)) ? 1 : 0;
            p.f_delta_real = (int)sc.Subgraph[SG_CVD_STORE].Arrays[2][b];
            p.f_suppressed = (int)(sc.Subgraph[SG_RAW_KAMA_ALIGN].Arrays[0][b]
                                 + sc.Subgraph[SG_RAW_KAMA_ALIGN].Arrays[1][b] > 0.5f);
            p.f_kama_align = (double)sc.Subgraph[SG_RAW_KAMA_ALIGN][b] / 100.0;
            p.f_ao_eff_len = (int)sc.Subgraph[SG_RAW_AO_EFF_LEN][b];
            p.f_rrg_votes  = (int)sc.Subgraph[SG_RAW_CCO].Arrays[1][b];
            p.f_sc_cco     = (double)sc.Subgraph[SG_SC_CCO][b];
            // per-bar TRG history (written by the main study every bar)
            p.f_trg_bull_votes = (int)sc.Subgraph[SG_RAW_KAMA_ALIGN].Arrays[2][b];
            p.f_trg_bear_votes = (int)sc.Subgraph[SG_RAW_KAMA_ALIGN].Arrays[3][b];
            p.f_hurst          = (double)sc.Subgraph[SG_RAW_KAMA_ALIGN].Arrays[4][b];
            // [v9.4] schema-v2 stashes: diagnostics + geometry + consensus + conf
            p.f_se_norm     = (double)sc.Subgraph[SG_RAW_ER].Arrays[5][b];
            p.f_fit_f       = (double)sc.Subgraph[SG_RAW_ER].Arrays[6][b];
            p.f_fit_r2      = (double)sc.Subgraph[SG_RAW_ER].Arrays[7][b];
            p.f_margin_atr  = (double)sc.Subgraph[SG_RAW_ER].Arrays[8][b];
            p.f_poly_slope  = (double)sc.Subgraph[SG_RAW_ER].Arrays[9][b];
            p.f_poly_curv   = (double)sc.Subgraph[SG_RAW_ER].Arrays[10][b];
            p.f_conf_pct    = (double)sc.Subgraph[SG_RAW_ER].Arrays[11][b];
            p.f_consensus   = (int)sc.Subgraph[SG_RAW_CCO].Arrays[5][b];
            s.pending.push_back(p);
        }
    }

    s.watermark = sc.BaseDateTimeIn[live - 1].GetAsDouble();
}
