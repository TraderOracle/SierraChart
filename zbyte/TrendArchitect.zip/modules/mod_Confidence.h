#pragma once
// mod_Confidence.h — [v9.4 NA-P3] Frozen logistic confidence score.
//
// A per-signal win probability from a logistic model fit OFFLINE by
// execution/analyze_signals.py (--fit-logistic → TA_weights.csv) over the
// already-logged gate features. Weights are loaded ONCE per full recalc into
// TAState (frozen — the of_data_present / est_sec_per_bar precedent), so
// history is deterministic within a recalc; a refreshed weights file only
// takes effect on the next recalc. Missing/malformed file → conf_loaded=false
// and the score stays -1 (display inert, no dimming, no demote). Display-only
// by default; the demote threshold defaults to 0 (off).
//
// The feature transform below is the CONTRACT with analyze_signals.py — the
// two must match exactly. 15 features x[0..14]; score z = w[0] + sum w[k+1]*x[k].

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
#include "../include/TA_State.h"

static const int CONF_NW = 16;   // w0 (bias) + 15 feature weights

inline int ta_conf_popcount4(int m) {
    return (m & 1) + ((m >> 1) & 1) + ((m >> 2) & 1) + ((m >> 3) & 1);
}
inline double ta_conf_clamp(double v, double lo, double hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

// Build the 15-feature vector at fire time (dir = +1 bull / -1 bear). Must
// mirror analyze_signals.py build_feature_vector() byte-for-byte in meaning.
inline void ta_conf_features(double* x, int dir,
    double er, double er_rank, double fk_norm, double bq_ratio,
    int cvd_agree, double cvd_rank, int chop, int sig_path, int elev_mask,
    int trg_bull, int trg_bear, double hurst, double kama_align,
    int rrg_votes, double margin_atr, double poly_slope /*already dir-signed*/)
{
    double d = (double)dir;
    x[0]  = er;
    x[1]  = (er_rank >= 0.0) ? er_rank / 100.0 : 0.5;   // 0.5 = N/A (adaptive off)
    x[2]  = ta_conf_clamp(d * fk_norm, -1.0, 1.0);
    x[3]  = bq_ratio;
    x[4]  = (double)cvd_agree;
    x[5]  = cvd_rank / 100.0;
    x[6]  = (double)chop;
    x[7]  = (sig_path == 0) ? 1.0 : 0.0;
    x[8]  = (double)ta_conf_popcount4(elev_mask) / 4.0;
    x[9]  = ta_conf_clamp(d * (double)(trg_bull - trg_bear) / 3.0, -1.0, 1.0);
    x[10] = 2.0 * (hurst - 0.5);
    x[11] = (double)rrg_votes / 3.0;
    x[12] = ta_conf_clamp(d * 2.0 * (kama_align - 0.5), -1.0, 1.0);
    x[13] = ta_conf_clamp(margin_atr / 0.25, 0.0, 1.0);
    x[14] = ta_conf_clamp(poly_slope / 0.10, -1.0, 1.0);
}

// Returns win probability in 0..100, or -1 if weights are not loaded.
inline double ta_conf_score(const TAState& tas, int dir,
    double er, double er_rank, double fk_norm, double bq_ratio,
    int cvd_agree, double cvd_rank, int chop, int sig_path, int elev_mask,
    int trg_bull, int trg_bear, double hurst, double kama_align,
    int rrg_votes, double margin_atr, double poly_slope)
{
    if (!tas.conf_loaded) return -1.0;
    double x[15];
    ta_conf_features(x, dir, er, er_rank, fk_norm, bq_ratio, cvd_agree, cvd_rank,
                     chop, sig_path, elev_mask, trg_bull, trg_bear, hurst,
                     kama_align, rrg_votes, margin_atr, poly_slope);
    double z = tas.conf_w[0];
    for (int k = 0; k < 15; k++) z += tas.conf_w[k + 1] * x[k];
    double p = 1.0 / (1.0 + std::exp(-z));
    return 100.0 * p;
}

// Load TA_weights.csv from the data folder and pick the best-matching row for
// (symbol, period). Called once at idx==0. Fail-soft: any problem → not loaded.
// CSV columns: symbol_pattern,period,n_rows,fit_date,version,w0..w15
// Match preference: exact (pattern==symbol && period) > longest pattern that is
// a prefix of symbol with matching period > global pattern "*".
inline void ta_load_conf_weights(SCStudyInterfaceRef sc, TAState& tas,
                                  const char* symbol, const char* period)
{
    tas.conf_loaded = false;
    tas.conf_version = 0;

    SCString path;
    path.Format("%s\\TA_weights.csv", sc.DataFilesFolder().GetChars());
    int h = 0;
    if (!sc.OpenFile(path, n_ACSIL::FILE_MODE_OPEN_EXISTING_FOR_SEQUENTIAL_READING, h))
        return;   // no weights file yet — normal until the first offline fit

    std::string buf;
    char chunk[4096];
    unsigned int got = 0;
    for (int guard = 0; guard < 4096; guard++) {   // cap ~16MB, far above real
        if (!sc.ReadFile(h, chunk, sizeof(chunk), &got) || got == 0) break;
        buf.append(chunk, got);
        if (got < sizeof(chunk)) break;
    }
    sc.CloseFile(h);
    if (buf.empty()) return;

    int best_score = -1;                 // higher = better match
    double best_w[CONF_NW] = {};
    int    best_version = 0;

    size_t pos = 0;
    bool header_skipped = false;
    while (pos < buf.size()) {
        size_t nl = buf.find('\n', pos);
        std::string line = buf.substr(pos, (nl == std::string::npos) ? std::string::npos : nl - pos);
        pos = (nl == std::string::npos) ? buf.size() : nl + 1;
        if (!line.empty() && line[line.size() - 1] == '\r') line.erase(line.size() - 1);
        if (line.empty()) continue;
        if (!header_skipped) { header_skipped = true; continue; }   // drop header

        // split on commas
        std::vector<std::string> f;
        size_t s = 0;
        while (true) {
            size_t c = line.find(',', s);
            f.push_back(line.substr(s, (c == std::string::npos) ? std::string::npos : c - s));
            if (c == std::string::npos) break;
            s = c + 1;
        }
        if ((int)f.size() < 5 + CONF_NW) continue;   // malformed row

        const std::string& pat = f[0];
        const std::string& per = f[1];
        // scoring: exact symbol == pat (+2), prefix of symbol (+len), global "*" (0)
        int score = -1;
        if (pat == symbol) score = 1000;
        else if (pat == "*") score = 0;
        else if (std::strncmp(symbol, pat.c_str(), pat.size()) == 0) score = (int)pat.size();
        if (score < 0) continue;
        // require period match unless the row is global (period "*")
        if (per != "*" && per != period) continue;
        if (score <= best_score) continue;

        double w[CONF_NW];
        bool ok = true;
        for (int k = 0; k < CONF_NW; k++) {
            const char* cs = f[5 + k].c_str();
            char* end = nullptr;
            w[k] = std::strtod(cs, &end);
            if (end == cs) { ok = false; break; }
        }
        if (!ok) continue;
        best_score = score;
        for (int k = 0; k < CONF_NW; k++) best_w[k] = w[k];
        best_version = std::atoi(f[4].c_str());
    }

    if (best_score >= 0) {
        for (int k = 0; k < CONF_NW; k++) tas.conf_w[k] = best_w[k];
        tas.conf_version = best_version;
        tas.conf_loaded  = true;
    }
}
